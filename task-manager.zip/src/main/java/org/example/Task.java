package org.example;

public class Task {
    private String name;
    private TaskStatus status;

    public Task(String name) {
        this.name = name;
        status = TaskStatus.ACTIVE;
    }

    public void markAsDone() {
        if (status != TaskStatus.DONE) {
            status = TaskStatus.DONE;
        }
    }
}
