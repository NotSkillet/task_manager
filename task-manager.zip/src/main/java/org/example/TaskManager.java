package org.example;

import java.util.*;

public class TaskManager {
    private final Map<TaskStatus, List<Task>> tasks = new EnumMap<>(TaskStatus.class);
    private final List<String> menu = new ArrayList<>();

    public TaskManager() {
        for (TaskStatus status : TaskStatus.values()) {
            tasks.put(status, new ArrayList<>());
        }
        menu.add("1 - Add a task");
        menu.add("2 - Mark a task as done");
        menu.add("3 - Show all tasks");
        menu.add("4 - Show all active tasks");
        menu.add("5 - Save tasks in CSV");
        menu.add("6 - Load tasks from CSV");
        menu.add("0 - Close the programme");
    }

    public void showMenu() {
        for (String option : menu) {
            System.out.println(option);
        }
    }
}
